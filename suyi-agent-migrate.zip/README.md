# Suyi 成长智能体

Suyi 的数字分身：成长日记 + 终身记忆 + AI 对话 + 时间邮局。

## 环境要求

- **Node.js 18 或更高版本**（https://nodejs.org 下载 LTS 版安装）

## 启动步骤

```bash
# 1. 进入项目目录
cd suyi-agent

# 2. 安装依赖（仅首次或换电脑时）
npm install

# 3. 启动
npm start
```

看到 `🌸 Suyi 成长智能体已启动: http://localhost:3000` 即成功。

浏览器打开 **http://localhost:3000**

## 数据说明

- 所有数据（日记/对话/里程碑/信件/记忆）都在 **suyi.db** 这一个文件里
- 照片在 **public/uploads/** 目录
- **备份 = 复制 suyi.db + public/uploads/ 两个东西即可**

## 配置（.env）

- `LLM_PROVIDER`：`deepseek` 或 `zhipu` 切换对话模型
- `DEEPSEEK_API_KEY` / `ZHIPU_API_KEY`：两家各自的 Key
- `DEEPSEEK_MODEL` / `ZHIPU_MODEL`：模型名
- ⚠️ 改动 .env 后需重启服务才生效
- ⚠️ .env 含 API Key，不要分享给别人

## 常用操作

- 换电脑迁移：整个目录拷走，新机执行 npm install && npm start
- 切换模型：改 .env 的 LLM_PROVIDER，重启
