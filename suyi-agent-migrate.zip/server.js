require('dotenv').config();
const express = require('express');
const path = require('path');
const fs = require('fs');
const db = require('./db');
const { buildSystemPrompt, chat, chatStream, extractMilestone, describeImage, generateReport, draftLetter,
  summarizeDiaries, summarizeSession, genAutoStage, generateGreeting } = require('./llm');

const app = express();
app.use(express.json({ limit: '20mb' })); // 20mb 以支持 base64 照片上传
app.use(express.static(path.join(__dirname, 'public')));

// 照片存储目录
const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---- 档案 ----
app.get('/api/profile', (req, res) => res.json(db.getProfile()));
app.put('/api/profile', (req, res) => res.json(db.updateProfile(req.body)));

// ---- 日记 ----
app.get('/api/diary', (req, res) => res.json(db.listDiary()));
app.post('/api/diary', async (req, res) => {
  const { date, content, tags, photo = '', photo_desc = '' } = req.body;
  if (!date || !content) return res.status(400).json({ error: 'date 和 content 必填' });
  const entry = db.addDiary({ date, content, tags, photo, photo_desc });
  res.json(entry);

  // 后台任务链（全部静默失败，不影响日记保存）
  const month = String(date).slice(0, 7);
  // ① 里程碑提取
  extractMilestone(entry, db.listMilestones())
    .then(r => {
      if (r.is_milestone && r.event) {
        db.addMilestone({ date, category: r.category || '其他', event: r.event, diary_id: entry.id });
        console.log(`⭐ 新里程碑: [${r.category}] ${r.event}`);
        // ② 人设自动演化：从里程碑生成最新能力概览
        genAutoStage(db.listMilestones().slice(0, 15))
          .then(s => { db.updateProfile({ auto_stage: s.trim() }); console.log('🧠 auto_stage 已更新:', s.trim().slice(0, 50)); })
          .catch(e => console.error('auto_stage更新失败(忽略):', e.message));
      }
    })
    .catch(e => console.error('里程碑提取失败(忽略):', e.message));
  // ③ 月度记忆摘要（当月）
  const monthDiaries = () => db.listDiary().filter(d => d.date.startsWith(month));
  summarizeDiaries(month, monthDiaries())
    .then(s => { db.upsertSummary('monthly', month, s); console.log(`📒 ${month} 月度摘要已生成`); })
    .catch(e => console.error('月度摘要失败(忽略):', e.message));
});
app.put('/api/diary/:id', (req, res) => {
  const { date, content, tags, photo = '', photo_desc = '' } = req.body;
  db.deleteMilestonesByDiary(Number(req.params.id)); // 编辑后旧提取结果作废
  res.json(db.updateDiary(Number(req.params.id), { date, content, tags, photo, photo_desc }));
});
app.delete('/api/diary/:id', (req, res) => {
  db.deleteMilestonesByDiary(Number(req.params.id));
  db.deleteDiary(Number(req.params.id));
  res.json({ ok: true });
});

// ---- 照片上传：保存文件 + 视觉描述（一次性消耗） ----
app.post('/api/photo', async (req, res) => {
  const { image } = req.body; // base64 dataURL
  if (!image?.startsWith('data:image/')) return res.status(400).json({ error: 'image 必须是 base64 dataURL' });
  try {
    const ext = image.slice(11, image.indexOf(';')) || 'jpeg';
    const name = `${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, name), Buffer.from(image.split(',')[1], 'base64'));
    let desc = '';
    try { desc = await describeImage(image); } catch (e) { console.error('视觉描述失败(忽略):', e.message); }
    res.json({ url: `/uploads/${name}`, desc });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---- 里程碑 ----
app.get('/api/milestones', (req, res) => res.json(db.listMilestones()));

// ---- 体检记录 ----
app.get('/api/health', (req, res) => res.json(db.listHealthRecords()));
app.post('/api/health', (req, res) => {
  const { date } = req.body;
  if (!date) return res.status(400).json({ error: 'date 必填' });
  db.addHealthRecord(req.body);
  res.json(db.listHealthRecords());
});
app.delete('/api/health/:id', (req, res) => {
  db.deleteHealthRecord(Number(req.params.id));
  res.json({ ok: true });
});

// ---- 月度成长报告 ----
app.post('/api/report', async (req, res) => {
  const { month } = req.body; // YYYY-MM
  if (!/^\d{4}-\d{2}$/.test(month || '')) return res.status(400).json({ error: 'month 格式应为 YYYY-MM' });
  try {
    const diaries = db.listDiary().filter(d => d.date.startsWith(month));
    const milestones = db.listMilestones().filter(m => m.date.startsWith(month));
    const healths = db.listHealthRecords().filter(h => h.date.startsWith(month));
    const report = await generateReport({ month, diaries, milestones, healths, profile: db.getProfile() });
    res.json({ report, stats: { diaries: diaries.length, milestones: milestones.length } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ---- 会话 ----
app.get('/api/sessions', (req, res) => res.json(db.listSessions()));
app.post('/api/sessions', (req, res) => res.json(db.addSession()));
app.delete('/api/sessions/:id', (req, res) => {
  db.deleteSession(Number(req.params.id));
  res.json({ ok: true });
});

// ---- 对话 ----
app.get('/api/messages', (req, res) => {
  const sid = Number(req.query.session_id) || null;
  res.json(sid ? db.listMessages(sid) : []);
});
app.delete('/api/messages', (req, res) => {
  const sid = Number(req.query.session_id);
  if (sid) db.clearMessages(sid);
  res.json({ ok: true });
});

// 组装分层记忆的上下文（对话/开场白共用）
function buildMemoryContext() {
  const profile = db.getProfile();
  const diary = db.recentDiary(20);
  const monthly = db.listSummaries('monthly');
  const milestones = db.listMilestones().slice(0, 15);
  const sessionSums = db.listSummaries('session').slice(0, 5);
  return { profile, diary, monthly, milestones, sessionSums };
}

app.post('/api/chat', async (req, res) => {
  const { message, mode = 'suyi', session_id } = req.body;
  if (!message?.trim()) return res.status(400).json({ error: 'message 必填' });

  try {
    // 会话不存在则自动创建，标题取第一句用户消息前20字
    let sessionId = Number(session_id) || null;
    const sessions = db.listSessions();
    const existing = sessionId && sessions.find(s => s.id === sessionId);
    if (!existing) {
      const s = db.addSession(message.trim().slice(0, 20));
      sessionId = s.id;
    }

    const { profile, diary, monthly, milestones, sessionSums } = buildMemoryContext();
    const system = buildSystemPrompt(mode, profile, diary,
      { monthlySummaries: monthly, milestones, sessionSummaries: sessionSums });

    // 只取当前会话的最近 12 条历史
    const history = db.recentMessages(sessionId, 12).map(m => ({ role: m.role, content: m.content }));
    const messages = [{ role: 'system', content: system }, ...history, { role: 'user', content: message }];

    // 流式输出：逐字推给前端，结束后整体落库
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    let full = '';
    try {
      full = await chatStream(messages, chunk => res.write(chunk));
    } catch (e) {
      // 流式失败：降级为非流式
      console.error('流式失败，降级非流式:', e.message);
      full = await chat(messages);
      res.write(full);
    }
    db.addMessage('user', message, mode, sessionId);
    db.addMessage('assistant', full, mode, sessionId);
    res.write(`\n\n@@DONE@@${sessionId}`);
    res.end();

    // 后台：会话消息数达到6的倍数 -> 生成/更新会话摘要
    if (db.listMessages(sessionId).length % 6 === 0) {
      summarizeSession(db.recentMessages(sessionId, 12))
        .then(s => db.upsertSummary('session', sessionId, s))
        .catch(e => console.error('会话摘要失败(忽略):', e.message));
    }
  } catch (err) {
    console.error(err);
    res.write(`\n\n@@ERROR@@${err.message}`);
    res.end();
  }
});

// ---- 主动开场白：新对话时她先说第一句 ----
app.post('/api/chat/greet', async (req, res) => {
  const { mode = 'suyi' } = req.body;
  try {
    const { profile, diary, milestones } = buildMemoryContext();
    const greeting = await generateGreeting({ mode, profile, recentDiaries: diary.slice(0, 3), milestones });
    // 存入一个新会话（作为第一条 assistant 消息）
    const s = db.addSession(mode === 'suyi' ? `她说：${greeting.slice(0, 15)}` : '成长助手对话');
    db.addMessage('assistant', greeting, mode, s.id);
    res.json({ greeting, session_id: s.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// ---- 时间邮局 ----
const today = () => new Date().toISOString().slice(0, 10);

// sealed 的信不返回正文（服务端强制保密直到解锁）
function letterView(l) {
  if (l.status === 'sealed') {
    const { content, ...meta } = l;
    meta.days_left = Math.ceil((new Date(l.unlock_at) - new Date(today())) / 86400000);
    return meta;
  }
  return l;
}

app.get('/api/letters', (req, res) => res.json(db.listLetters().map(letterView)));

app.post('/api/letters', (req, res) => {
  const { title, content, author, recipient, unlock_at, diary_id } = req.body;
  if (!unlock_at) return res.status(400).json({ error: 'unlock_at 必填' });
  res.json(db.addLetter({ title, content, author, recipient, unlock_at, diary_id }));
});

app.put('/api/letters/:id', (req, res) => {
  const updated = db.updateLetter(Number(req.params.id), req.body);
  if (!updated) return res.status(400).json({ error: '只有草稿状态可以编辑' });
  res.json(updated);
});

app.delete('/api/letters/:id', (req, res) => {
  db.deleteLetter(Number(req.params.id));
  res.json({ ok: true });
});

app.post('/api/letters/:id/seal', (req, res) => res.json(db.sealLetter(Number(req.params.id))));
app.post('/api/letters/:id/void', (req, res) => res.json(db.voidLetter(Number(req.params.id))));
app.post('/api/letters/:id/open', (req, res) => {
  const l = db.getLetter(Number(req.params.id));
  if (!l) return res.status(404).json({ error: '信不存在' });
  if (l.status !== 'sealed') return res.status(400).json({ error: '只有已封存的信可以拆' });
  if (l.unlock_at > today()) return res.status(403).json({ error: `还没到解锁日（${l.unlock_at}）` });
  res.json(db.openLetter(l.id));
});

// AI 代笔（生成草稿，不自动封存）
app.post('/api/letters/ai-draft', async (req, res) => {
  const { style = 'assist', month, userNote = '' } = req.body;
  try {
    const profile = db.getProfile();
    const t = today();
    let diaries = [], milestones = [], healths = [];
    if (style === 'snapshot' && month) {
      diaries = db.listDiary().filter(d => d.date.startsWith(month));
      milestones = db.listMilestones().filter(m => m.date.startsWith(month));
      healths = db.listHealthRecords().filter(h => h.date.startsWith(month));
    } else {
      diaries = db.recentDiary(5);
    }
    const content = await draftLetter({ style, profile, today: t, month, diaries, milestones, healths, userNote });
    const title = style === 'suyi_voice' ? '来自现在的小Suyi' : style === 'snapshot' ? `${month} 时光快照` : '一封写给未来的信';
    const author = style === 'suyi_voice' ? 'AI-Suyi口吻(待审)' : style === 'snapshot' ? 'AI-时光快照(待审)' : 'AI-家长起笔(待审)';
    const unlockDefault = style === 'snapshot'
      ? `${new Date().getFullYear() + 18}-${profile.birthday.slice(5)}`  // 默认18岁生日
      : `${new Date().getFullYear() + 1}-${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`;
    const letter = db.addLetter({ title, content, author, recipient: 'Suyi', unlock_at: unlockDefault });
    res.json(letter);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// 启动检查：当月有日记但还没有当月快照草稿 -> 自动生成一份草稿（不封存）
async function ensureMonthlySnapshot() {
  const month = today().slice(0, 7);
  const hasDiary = db.listDiary().some(d => d.date.startsWith(month));
  const hasSnapshot = db.listLetters().some(l => l.author.includes('时光快照') && l.created_at.startsWith(month));
  if (!hasDiary || hasSnapshot) return;
  try {
    const profile = db.getProfile();
    const diaries = db.listDiary().filter(d => d.date.startsWith(month));
    const milestones = db.listMilestones().filter(m => m.date.startsWith(month));
    const healths = db.listHealthRecords().filter(h => h.date.startsWith(month));
    const content = await draftLetter({ style: 'snapshot', profile, today: today(), month, diaries, milestones, healths });
    db.addLetter({ title: `${month} 时光快照`, content, author: 'AI-时光快照(待审)', recipient: 'Suyi',
      unlock_at: `${new Date().getFullYear() + 18}-${profile.birthday.slice(5)}` });
    console.log(`📮 已自动生成 ${month} 时光快照草稿（待审核封存）`);
  } catch (e) { console.error('快照生成失败(忽略):', e.message); }
}

// 启动检查：有日记但缺月度摘要的月份 -> 后台补齐（历史回填）
async function backfillMonthlySummaries() {
  const months = [...new Set(db.listDiary().map(d => d.date.slice(0, 7)))];
  for (const month of months) {
    if (db.getSummary('monthly', month)) continue;
    const diaries = db.listDiary().filter(d => d.date.startsWith(month));
    if (!diaries.length) continue;
    try {
      const s = await summarizeDiaries(month, diaries);
      db.upsertSummary('monthly', month, s);
      console.log(`📒 已回填 ${month} 月度摘要`);
    } catch (e) { console.error(`${month} 摘要回填失败(忽略):`, e.message); }
  }
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🌸 Suyi 成长智能体已启动: http://localhost:${PORT}`);
  ensureMonthlySnapshot();
  backfillMonthlySummaries();
});
