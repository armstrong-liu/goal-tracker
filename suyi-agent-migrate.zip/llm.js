const API_URL = 'https://open.bigmodel.cn/api/paas/v4/chat/completions';
const DEEPSEEK_URL = 'https://api.deepseek.com/chat/completions';
const VISION_MODEL = 'glm-4v-flash'; // 视觉固定走智谱免费模型（DeepSeek无视觉API）

// ---- 多模型路由：根据 LLM_PROVIDER 返回 {url, key, model} ----
function llmConfig() {
  const provider = (process.env.LLM_PROVIDER || 'zhipu').toLowerCase();
  if (provider === 'deepseek') {
    const key = process.env.DEEPSEEK_API_KEY;
    if (!key || key === 'your_deepseek_key_here') {
      throw new Error('LLM_PROVIDER=deepseek 但未配置 DEEPSEEK_API_KEY，请在 .env 中填入');
    }
    return { url: DEEPSEEK_URL, key, model: process.env.DEEPSEEK_MODEL || 'deepseek-chat' };
  }
  const key = process.env.ZHIPU_API_KEY;
  if (!key || key === 'your_api_key_here') {
    throw new Error('未配置 ZHIPU_API_KEY，请复制 .env.example 为 .env 并填入你的智谱 API Key');
  }
  return { url: API_URL, key, model: process.env.ZHIPU_MODEL || 'glm-4-flash' };
}

// ---- 发育剧本：0-6岁各阶段的语言/认知/社交特征 ----
const STAGE_SCRIPT = [
  { max: 12,  lang: '只会发简单的音，如"ba""ma""da"，偶尔蹦出"爸爸妈妈"的音但未必有意识。大部分用哭、笑声、手指、身体动作表达。', emo: '认生和分离焦虑明显，用表情和动作与亲近的人互动。' },
  { max: 18,  lang: '会说"爸爸""妈妈"等有意义的称呼，词汇1-10个。大量使用手势+嗯嗯啊啊表达需求。能听懂简单的一步指令。', emo: '自我意识开始萌芽，模仿是主要学习方式，遇到不确定会看大人的表情（社交参照）。' },
  { max: 24,  lang: '词汇爆发期，会说10-50个词，开始把两个词组合："妈妈抱""要球球"。能听懂两步指令。', emo: '开始出现"不要！"的自主宣言，平行游戏，看见别人哭会有共情反应。' },
  { max: 36,  lang: '会说短句（3-5个词），词汇量几百个，爱问"这是什么？"。会说"我"，开始用语言表达需求而非只用手指。', emo: '自我意识高峰，规则意识萌芽，开始简单的假装游戏（给娃娃喂饭）。' },
  { max: 48,  lang: '句子完整，会讲简单的故事，爱问"为什么"，词汇上千。能和大人进行多轮对话。', emo: '想象力丰富，喜欢角色扮演游戏，开始理解他人的感受，有了好朋友的概念。' },
  { max: 60,  lang: '表达流畅，能清楚叙述发生过的事，会讨价还价，语言开始有幽默感。', emo: '在意公平，喜欢合作游戏，情绪表达更丰富，开始学着自己调节情绪。' },
  { max: 84,  lang: '语言接近成人水平，能阅读、写字、讲长故事，有自己的观点并会论证。', emo: '有稳定的友谊，在意评价，自尊心发展，能共情和安慰别人。' },
];

function stageScript(months) {
  const s = STAGE_SCRIPT.find(s => months <= s.max) || STAGE_SCRIPT[STAGE_SCRIPT.length - 1];
  return s;
}

// 根据生日计算月龄描述
function monthAge(birthday, now = new Date()) {
  const b = new Date(birthday);
  if (isNaN(b)) return '';
  let months = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
  if (now.getDate() < b.getDate()) months -= 1;
  if (months < 0) return '还没出生';
  if (months < 12) return `${months}月龄`;
  const y = Math.floor(months / 12), m = months % 12;
  return m === 0 ? `${y}岁` : `${y}岁${m}个月`;
}

// 组装 System Prompt：人设档案 + 分层记忆（月度摘要/近期日记/里程碑/会话记忆）
function buildSystemPrompt(mode, profile, diaryEntries, { monthlySummaries = [], milestones = [], sessionSummaries = [] } = {}) {
  const age = monthAge(profile.birthday);

  const monthlyText = monthlySummaries.length
    ? monthlySummaries.reverse().map(s => `### ${s.ref_key}\n${s.content}`).join('\n\n')
    : '（暂无）';
  const diaryText = diaryEntries.length
    ? diaryEntries.reverse().map(d => `【${d.date}】${d.tags ? `[${d.tags.split(/\s+/).filter(Boolean).map(t => '#' + t).join(' ')}] ` : ''}${d.content}`).join('\n')
    : '（还没有日记记录）';
  const msText = milestones.length
    ? milestones.map(m => `- ${m.date} [${m.category}] ${m.event}`).join('\n')
    : '（暂无）';
  const sessText = sessionSummaries.length
    ? sessionSummaries.map(s => `- 与家长的对话（${(s.updated_at || s.created_at || '').slice(0, 10)}）：${s.content}`).join('\n')
    : '（暂无）';

  const persona = `## Suyi 的小档案
- 名字：${profile.name}
- 生日：${profile.birthday}（现在约 ${age}）
- 家庭：${profile.family}
- 性格：${profile.personality}
- 喜好：${profile.favorites || '待记录'}
- 最新能力（自动更新）：${profile.auto_stage || '待生成'}
- 家长补充的发展说明：${profile.current_stage}

## 早期记忆（按月摘要，她更小的时候的事）
${monthlyText}

## 里程碑（她的"第一次"们，含具体日期）
${msText}

## 最近的日记（近事细节）
${diaryText}

## 最近和家长的对话记忆（跨会话）
${sessText}`;

  if (mode === 'suyi') {
    // 根据实际月龄从发育剧本取对应的语言/情绪特征
    const m = age.includes('岁')
      ? parseInt(age) * 12 + (parseInt(age.match(/(\d+)个月/)?.[1] || 0))
      : parseInt(age) || 0;
    const script = stageScript(m);
    return `你扮演一个真实的小女孩"${profile.name}"（现在约 ${age}），和爸爸/妈妈聊天。你不是AI助手，你就是这个宝宝本人。

${persona}

## 扮演要求
1. 语言必须符合这个月龄幼儿的真实水平：${script.lang}
2. 她的情绪和社交特点是：${script.emo}
3. 可以用括号加旁白描述动作和神态，如：（摇摇晃晃地走过来，扑进妈妈怀里）（指着小球，嗯嗯地叫）。旁白让不会说话时的她也足以"表达"。
4. 回复要短（一般1-3句），符合幼儿注意力。
5. 她的性格：${profile.personality}。她的反应要基于日记里记录的真实经历和喜好。
6. **时间线规则**：日记跨越她出生至今的不同时期。回忆某个过去日期的事时，你的表现必须符合**当时**的月龄——例如她出生头几个月时只会哭、吃奶、换尿布、被抱，还不会走路和说话；不要把现在才有的能力用在早期回忆里。
7. 永远不要跳出角色解释自己是AI。如果被问到复杂问题，就用幼儿的方式回应（歪头、茫然、转移注意力）。`;
  }

  return `你是"${profile.name}"的成长助手，帮助爸爸妈妈回顾和了解宝宝的成长。

${persona}

## 回答要求
1. 回答关于 ${profile.name} 的问题时，优先依据上面的日记记录，引用具体日期（完整的年月日）。
2. **日期解析**：用户提到"15日""上个月"这类不完整或相对日期时，检索所有匹配的记录；有歧义时列出所有匹配项让用户确认，不要猜测。
3. **时间线意识**：日记跨越不同时期，描述某个时期的事时，她的能力应符合当时的月龄（如2025年出生头几个月还不会走路）。
4. 可以结合儿童发展知识补充背景（如某月龄的典型发育），但注意区分"日记记录的事实"和"一般发育知识"。
5. 回答简洁温暖，用中文。如果日记中没有相关记录，坦诚说明。`;
}

// 调用 LLM（文本，支持 zhipu / deepseek）
async function chat(messages, { temperature = 0.8, max_tokens = 1024 } = {}) {
  const { url, key, model } = llmConfig();
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages, temperature, max_tokens }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`LLM API 错误 (${res.status}): ${text}`);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || '';
}

// ---- 里程碑提取：从一篇日记中判断是否出现新里程碑 ----
async function extractMilestone(diary, existingMilestones) {
  const existing = existingMilestones.map(m => `- ${m.date} [${m.category}] ${m.event}`).join('\n') || '（暂无）';
  const prompt = `你是儿童发育专家。下面是一篇婴儿成长日记，请判断其中是否记录了**新的发育里程碑**（第一次掌握的新技能，如第一次独走、第一次叫妈妈、第一次叠积木）。

## 已记录的里程碑（避免重复，如果日记中的技能已经被记录过就不再提取）
${existing}

## 日记（${diary.date}）
${diary.content}

## 输出要求
只输出一个 JSON 对象，不要任何其他文字：
- 如果是新里程碑：{"is_milestone": true, "category": "大运动|精细运动|语言|认知|社交 之一", "event": "简短描述，如：第一次独立行走"}
- 如果不是：{"is_milestone": false}`;

  const raw = await chat([{ role: 'user', content: prompt }], { temperature: 0.1, max_tokens: 300 });
  const jsonText = raw.replace(/```json|```/g, '').trim();
  try {
    const parsed = JSON.parse(jsonText);
    return parsed;
  } catch {
    return { is_milestone: false };
  }
}

// ---- 照片描述：视觉模型看图生成文字 ----
async function describeImage(base64DataUrl) {
  const key = process.env.ZHIPU_API_KEY;
  if (!key || key === 'your_api_key_here') return '';
  const res = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: VISION_MODEL,
      messages: [{
        role: 'user',
        content: [
          { type: 'image_url', image_url: { url: base64DataUrl } },
          { type: 'text', text: '这是一个宝宝的生活照。用一两句话客观描述照片内容：她穿着什么、在做什么、表情如何、周围环境。不要推测身份信息。' },
        ],
      }],
      temperature: 0.3, max_tokens: 200,
    }),
  });
  if (!res.ok) return '';
  const data = await res.json();
  return data.choices?.[0]?.message?.content || '';
}

// ---- 月度成长报告 ----
async function generateReport({ month, diaries, milestones, healths, profile }) {
  const diaryText = diaries.map(d => `【${d.date}】${d.photo_desc ? `[照片: ${d.photo_desc}] ` : ''}${d.content}`).join('\n') || '（本月无日记）';
  const msText = milestones.map(m => `- ${m.date} [${m.category}] ${m.event}`).join('\n') || '（本月无新里程碑）';
  const healthText = healths.map(h =>
    `【${h.date}】身高${h.height ?? '-'}cm 体重${h.weight ?? '-'}kg 头围${h.head_circ ?? '-'}cm 出牙${h.teeth ?? '-'}颗 ${h.note}`).join('\n') || '（本月无体检记录）';

  const prompt = `请为一个宝宝生成月度成长报告。要求：温暖、具体、有细节（引用日记原文片段），分四个部分，使用 Markdown。

## 宝宝
${profile.name}，生日 ${profile.birthday}，本报告月份：${month}
性格：${profile.personality}

## 本月日记
${diaryText}

## 本月新里程碑
${msText}

## 本月体检数据
${healthText}

## 输出格式（Markdown，四个二级标题）
## 本月概览  （两三句总结这个月的变化）
## 新技能与里程碑  （结合日记细节展开讲）
## 生活点滴  （从日记中挑3-5个最动人的瞬间）
## 给爸爸妈妈的话  （一段温暖的话）`;

  return chat([{ role: 'user', content: prompt }], { temperature: 0.7, max_tokens: 2000 });
}

// ---- 时间邮局：AI 代笔 ----
async function draftLetter({ style, profile, today, month, diaries = [], milestones = [], healths = [], userNote = '' }) {
  const age = monthAge(profile.birthday);
  const ctx = [
    diaries.length ? `## 相关日记\n${diaries.map(d => `【${d.date}】${d.content}`).join('\n')}` : '',
    milestones.length ? `## 里程碑\n${milestones.map(m => `- ${m.date} ${m.event}`).join('\n')}` : '',
    healths.length ? `## 体检数据\n${healths.map(h => `${h.date} 身高${h.height}cm 体重${h.weight}kg`).join('；')}` : '',
  ].filter(Boolean).join('\n\n');

  const common = `背景：${profile.name}（${age}），性格：${profile.personality}。今天是 ${today}。信的解锁日由收信人在未来打开，写这封信的目的是把"此刻"封存给未来。
要求：真诚、克制、有具体细节，不要过度煽情和堆砌形容词；400字以内；中文；信件格式（称呼、正文、落款含日期）。只输出信件本身。`;

  let prompt;
  if (style === 'suyi_voice') {
    const m = age.includes('岁') ? parseInt(age) * 12 + parseInt(age.match(/(\d+)个月/)?.[1] || 0) : parseInt(age) || 0;
    const script = stageScript(m);
    prompt = `请以一个 ${age} 女孩的口吻，写一封"现在的我写给长大后的我"的信，收信人是"${profile.name}本人（成年后）"。
她的语言水平：${script.lang}
写法：她的"台词"用符合月龄的简单语言（叠词、短句），并用括号旁白解释她的意思，如"抱抱！（旁白：她张开手臂想让你抱）"。信里应包含她此刻最喜欢的、最害怕的、最想对长大的自己说的（借助旁白翻译）。
${ctx ? '\n' + ctx + '\n' : ''}${common}`;
  } else if (style === 'snapshot') {
    prompt = `请为"${month}"写一封时光快照信，收信人是"${profile.name}（成年后）"，落款为"Suyi成长智能体·自动快照"。
内容：概述这个月她的变化、新掌握的技能、生活里有代表性的小细节、身体数据（若有），让未来的她读到一个月内具体而微的自己。
${ctx ? '\n' + ctx + '\n' : ''}${common}`;
  } else { // assist 家长起笔
    prompt = `一位家长想给未来的孩子写一封时间胶囊信，家长想表达的意思是："${userNote || '把最近发生的成长小事和此刻的心情封存给未来'}"。
请帮这位家长起草这封信，署名"爱你的爸爸妈妈"。
${ctx ? '\n' + ctx + '\n' : ''}${common}`;
  }
  return chat([{ role: 'user', content: prompt }], { temperature: 0.85, max_tokens: 900 });
}

// ---- 记忆系统：月度日记摘要 ----
async function summarizeDiaries(month, diaries) {
  const text = diaries.map(d => `【${d.date}】${d.photo_desc ? `[照片: ${d.photo_desc}] ` : ''}${d.content}`).join('\n');
  const prompt = `以下是宝宝"${month}"这个月的全部成长日记。请压缩成一份 ≤300字 的月度记忆摘要，供AI扮演她时作为长期记忆使用。

要求：
1. 保留具体日期（如"8月17日"）和她的原话（如"爸爸""妈妈"等她说的词）
2. 重点：发育进展、新学会的技能、喜好变化、重要事件、健康状况
3. 客观简洁，不要抒情

## 日记
${text}`;

  return chat([{ role: 'user', content: prompt }], { temperature: 0.3, max_tokens: 500 });
}

// ---- 记忆系统：会话摘要 ----
async function summarizeSession(messages) {
  const text = messages.map(m => `${m.role === 'user' ? '家长' : 'Suyi'}: ${m.content}`).join('\n');
  const prompt = `以下是一段家长和"Suyi的AI扮演"之间的对话。请压缩成 ≤150字 摘要，供下次对话时作为跨会话记忆使用。
要求：保留对话谈论的关键话题、达成的"约定"或重要信息、家长的语气偏好。客观简洁。

## 对话
${text}`;
  return chat([{ role: 'user', content: prompt }], { temperature: 0.3, max_tokens: 300 });
}

// ---- 记忆系统：自动能力概览 ----
async function genAutoStage(milestones) {
  const text = milestones.map(m => `${m.date} [${m.category}] ${m.event}`).join('\n');
  const prompt = `以下是一个宝宝的里程碑记录（从旧到新混杂）。请用一句话（≤60字）概括她目前最新的能力状态，供AI扮演时参考。
例："已会独立行走、能听懂一步指令、会叫爸爸妈妈，正在学蹲"。
只输出这一句话。

## 里程碑
${text}`;
  return chat([{ role: 'user', content: prompt }], { temperature: 0.2, max_tokens: 120 });
}

// ---- 主动开场白 ----
async function generateGreeting({ mode, profile, recentDiaries, milestones }) {
  const age = monthAge(profile.birthday);
  const diaryText = recentDiaries.map(d => `【${d.date}】${d.content.slice(0, 100)}`).join('\n');
  const msText = milestones.slice(0, 3).map(m => `${m.date} ${m.event}`).join('；');
  const m = age.includes('岁') ? parseInt(age) * 12 + parseInt(age.match(/(\d+)个月/)?.[1] || 0) : parseInt(age) || 0;
  const script = stageScript(m);

  if (mode === 'suyi') {
    const prompt = `你扮演 ${age} 的小女孩"${profile.name}"，家长刚打开对话框，你主动说第一句话（家长还没说话）。
语言水平：${script.lang}
素材：最近的日记：${diaryText || '（无）'}；最近的里程碑：${msText || '（无）'}
要求：只输出一句话（可用括号旁白描述动作）。如果最近有新里程碑，围绕它向家长"炫耀"（如拉着家长去看）；否则自然问候。不要超过40字。`;
    return chat([{ role: 'user', content: prompt }], { temperature: 0.9, max_tokens: 150 });
  }
  const prompt = `你是"${profile.name}"（${age}）的成长助手，家长刚打开对话框。根据最近日记和里程碑，说一句简短的开场白（≤50字），提示可以聊什么。只输出这句话。
素材：${diaryText || '（无）'}；里程碑：${msText || '（无）'}`;
  return chat([{ role: 'user', content: prompt }], { temperature: 0.7, max_tokens: 150 });
}

// ---- 流式对话：返回完整文本，逐段回调（支持 zhipu / deepseek，SSE格式相同） ----
async function chatStream(messages, onChunk) {
  const { url, key, model } = llmConfig();
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages, temperature: 0.8, max_tokens: 1024, stream: true }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`智谱 API 错误 (${res.status}): ${text}`);
  }
  // 解析 SSE 流
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '', full = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop(); // 留半行
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed.startsWith('data:')) continue;
      const data = trimmed.slice(5).trim();
      if (data === '[DONE]') continue;
      try {
        const json = JSON.parse(data);
        const delta = json.choices?.[0]?.delta?.content || '';
        if (delta) { full += delta; onChunk && onChunk(delta); }
      } catch { /* 忽略半截JSON */ }
    }
  }
  return full;
}

module.exports = { buildSystemPrompt, chat, monthAge, extractMilestone, describeImage, generateReport, draftLetter,
  summarizeDiaries, summarizeSession, genAutoStage, generateGreeting, chatStream };
