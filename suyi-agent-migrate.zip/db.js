const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'suyi.db'));
db.pragma('journal_mode = WAL');

// ---- 初始化表结构 ----
db.exec(`
CREATE TABLE IF NOT EXISTS diary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,           -- YYYY-MM-DD
  content TEXT NOT NULL,
  tags TEXT DEFAULT '',         -- 空格分隔，如: 里程碑 第一次 趣事
  photo TEXT DEFAULT '',        -- 照片路径 public/uploads/xxx.jpg
  photo_desc TEXT DEFAULT '',   -- 视觉模型生成的照片描述
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  category TEXT NOT NULL,       -- 大运动/精细运动/语言/认知/社交
  event TEXT NOT NULL,
  diary_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS health_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT NOT NULL,
  height REAL,                  -- cm
  weight REAL,                  -- kg
  head_circ REAL,               -- cm
  teeth INTEGER,                -- 出牙数
  note TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL,           -- user / assistant
  content TEXT NOT NULL,
  mode TEXT DEFAULT 'suyi',     -- suyi / helper
  session_id INTEGER,           -- 所属会话
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS letters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT DEFAULT '',
  content TEXT DEFAULT '',
  author TEXT DEFAULT '家长',
  recipient TEXT DEFAULT 'Suyi',
  status TEXT DEFAULT 'draft',        -- draft / sealed / opened / void
  unlock_at TEXT NOT NULL,            -- 解锁日 YYYY-MM-DD
  diary_id INTEGER,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  sealed_at TEXT,
  opened_at TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT DEFAULT '新对话',
  created_at TEXT DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS memory_summaries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,               -- monthly / session
  ref_key TEXT NOT NULL,            -- monthly: '2026-08'; session: 会话id
  content TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now','localtime')),
  updated_at TEXT,
  UNIQUE(kind, ref_key)
);

CREATE TABLE IF NOT EXISTS profile (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_diary_date ON diary(date);
`);

// ---- 轻量迁移：给旧库补新列 ----
const existingCols = new Set(db.prepare("PRAGMA table_info(diary)").all().map(c => c.name));
for (const [col, ddl] of [['photo', "ALTER TABLE diary ADD COLUMN photo TEXT DEFAULT ''"], ['photo_desc', "ALTER TABLE diary ADD COLUMN photo_desc TEXT DEFAULT ''"]]) {
  if (!existingCols.has(col)) db.exec(ddl);
}
// messages 加 session_id 列
const msgCols = new Set(db.prepare("PRAGMA table_info(messages)").all().map(c => c.name));
if (!msgCols.has('session_id')) {
  db.exec("ALTER TABLE messages ADD COLUMN session_id INTEGER");
  // 存量消息归入一个"历史对话"会话（若有存量）
  const hasOld = db.prepare("SELECT COUNT(*) AS n FROM messages").get().n > 0;
  if (hasOld) {
    const info = db.prepare("INSERT INTO sessions (title) VALUES ('历史对话')").run();
    db.prepare("UPDATE messages SET session_id = ? WHERE session_id IS NULL").run(info.lastInsertRowid);
  }
}

// ---- 档案（key-value，默认值在首次读取时写入）----
const DEFAULT_PROFILE = {
  name: 'Suyi',
  birthday: '2025-05-15',
  current_stage: '15月龄。已学会独立行走（还摇摇晃晃），一蹲就坐在地上。特别喜欢模仿大人的动作。能听懂简单指令，让她拿东西能很快拿过来。会叫"爸爸""妈妈"了。每天补AD，喝奶粉，吃肉鱼蔬菜。',
  personality: '活泼、好奇、爱模仿、专注观察大人做事',
  favorites: '',
  family: '爸爸、妈妈',
  auto_stage: '',
};

const profileStmts = {
  get: db.prepare('SELECT value FROM profile WHERE key = ?'),
  set: db.prepare('INSERT INTO profile (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'),
  listAll: db.prepare('SELECT key, value FROM profile'),
};

function getProfile() {
  const row = {};
  for (const p of profileStmts.listAll.all()) row[p.key] = p.value;
  return { ...DEFAULT_PROFILE, ...row };
}

function updateProfile(patch) {
  const tx = db.transaction((entries) => {
    for (const [key, value] of entries) {
      if (key in DEFAULT_PROFILE && typeof value === 'string') profileStmts.set.run(key, value);
    }
  });
  tx(Object.entries(patch));
  return getProfile();
}

// ---- 日记 ----
const diaryStmts = {
  insert: db.prepare('INSERT INTO diary (date, content, tags, photo, photo_desc) VALUES (?, ?, ?, ?, ?)'),
  update: db.prepare('UPDATE diary SET date = ?, content = ?, tags = ?, photo = ?, photo_desc = ? WHERE id = ?'),
  delete: db.prepare('DELETE FROM diary WHERE id = ?'),
  listAll: db.prepare('SELECT * FROM diary ORDER BY date DESC, id DESC'),
  byId: db.prepare('SELECT * FROM diary WHERE id = ?'),
  recent: db.prepare('SELECT * FROM diary ORDER BY date DESC, id DESC LIMIT ?'),
};

function addDiary({ date, content, tags = '', photo = '', photo_desc = '' }) {
  const info = diaryStmts.insert.run(date, content, tags, photo, photo_desc);
  return diaryStmts.byId.get(info.lastInsertRowid);
}

function updateDiary(id, { date, content, tags, photo = '', photo_desc = '' }) {
  diaryStmts.update.run(date, content, tags, photo, photo_desc, id);
  return diaryStmts.byId.get(id);
}

function deleteDiary(id) {
  diaryStmts.delete.run(id);
}

function listDiary() {
  return diaryStmts.listAll.all();
}

function recentDiary(n = 30) {
  return diaryStmts.recent.all(n);
}

// ---- 里程碑 ----
const msStmts = {
  insert: db.prepare('INSERT INTO milestones (date, category, event, diary_id) VALUES (?, ?, ?, ?)'),
  listAll: db.prepare('SELECT * FROM milestones ORDER BY date DESC, id DESC'),
  byId: db.prepare('SELECT * FROM milestones WHERE id = ?'),
  deleteByDiary: db.prepare('DELETE FROM milestones WHERE diary_id = ?'),
};

function addMilestone({ date, category, event, diary_id }) {
  const info = msStmts.insert.run(date, category, event, diary_id);
  return msStmts.byId.get(info.lastInsertRowid);
}
function listMilestones() { return msStmts.listAll.all(); }
function deleteMilestonesByDiary(diaryId) { msStmts.deleteByDiary.run(diaryId); }

// ---- 体检记录 ----
const hrStmts = {
  insert: db.prepare('INSERT INTO health_records (date, height, weight, head_circ, teeth, note) VALUES (?, ?, ?, ?, ?, ?)'),
  listAll: db.prepare('SELECT * FROM health_records ORDER BY date ASC'),
  delete: db.prepare('DELETE FROM health_records WHERE id = ?'),
};

function addHealthRecord(r) {
  hrStmts.insert.run(r.date, r.height ?? null, r.weight ?? null, r.head_circ ?? null, r.teeth ?? null, r.note || '');
}
function listHealthRecords() { return hrStmts.listAll.all(); }
function deleteHealthRecord(id) { hrStmts.delete.run(id); }

// ---- 时间邮局 ----
const letterStmts = {
  insert: db.prepare(`INSERT INTO letters (title, content, author, recipient, unlock_at, diary_id, status)
                      VALUES (?, ?, ?, ?, ?, ?, 'draft')`),
  update: db.prepare(`UPDATE letters SET title = ?, content = ?, author = ?, recipient = ?, unlock_at = ?, diary_id = ? WHERE id = ? AND status = 'draft'`),
  delete: db.prepare(`DELETE FROM letters WHERE id = ? AND status = 'draft'`),
  seal: db.prepare(`UPDATE letters SET status = 'sealed', sealed_at = datetime('now','localtime') WHERE id = ? AND status = 'draft'`),
  void: db.prepare(`UPDATE letters SET status = 'void' WHERE id = ? AND status IN ('draft','sealed')`),
  open: db.prepare(`UPDATE letters SET status = 'opened', opened_at = datetime('now','localtime') WHERE id = ? AND status = 'sealed'`),
  listAll: db.prepare(`SELECT * FROM letters ORDER BY created_at DESC`),
  byId: db.prepare('SELECT * FROM letters WHERE id = ?'),
};

function addLetter({ title = '', content = '', author = '家长', recipient = 'Suyi', unlock_at, diary_id = null }) {
  const info = letterStmts.insert.run(title, content, author, recipient, unlock_at, diary_id);
  return letterStmts.byId.get(info.lastInsertRowid);
}
function updateLetter(id, patch) {
  const cur = letterStmts.byId.get(id);
  if (!cur || cur.status !== 'draft') return null;
  letterStmts.update.run(
    patch.title ?? cur.title, patch.content ?? cur.content,
    patch.author ?? cur.author, patch.recipient ?? cur.recipient,
    patch.unlock_at ?? cur.unlock_at, patch.diary_id ?? cur.diary_id, id
  );
  return letterStmts.byId.get(id);
}
function deleteLetter(id) { letterStmts.delete.run(id); }
function sealLetter(id) { letterStmts.seal.run(id); return letterStmts.byId.get(id); }
function voidLetter(id) { letterStmts.void.run(id); return letterStmts.byId.get(id); }
function openLetter(id) { letterStmts.open.run(id); return letterStmts.byId.get(id); }
function listLetters() { return letterStmts.listAll.all(); }
function getLetter(id) { return letterStmts.byId.get(id); }

// ---- 会话 ----
const sessionStmts = {
  insert: db.prepare("INSERT INTO sessions (title) VALUES (?)"),
  rename: db.prepare('UPDATE sessions SET title = ? WHERE id = ?'),
  delete: db.prepare('DELETE FROM sessions WHERE id = ?'),
  listAll: db.prepare(`
    SELECT s.id, s.title, s.created_at,
           (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id) AS msg_count,
           (SELECT MAX(m.created_at) FROM messages m WHERE m.session_id = s.id) AS last_at
    FROM sessions s ORDER BY COALESCE(last_at, s.created_at) DESC`),
  byId: db.prepare('SELECT * FROM sessions WHERE id = ?'),
};

function addSession(title = '新对话') {
  const info = sessionStmts.insert.run(title);
  return sessionStmts.byId.get(info.lastInsertRowid);
}
function renameSession(id, title) { sessionStmts.rename.run(title, id); }
function deleteSession(id) {
  db.prepare('DELETE FROM messages WHERE session_id = ?').run(id);
  sessionStmts.delete.run(id);
}
function listSessions() { return sessionStmts.listAll.all(); }

// ---- 对话历史 ----
const msgStmts = {
  insert: db.prepare('INSERT INTO messages (role, content, mode, session_id) VALUES (?, ?, ?, ?)'),
  listAll: db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC'),
  recent: db.prepare('SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?'),
  clear: db.prepare('DELETE FROM messages WHERE session_id = ?'),
};

function addMessage(role, content, mode, sessionId) {
  msgStmts.insert.run(role, content, mode, sessionId);
}

function listMessages(sessionId) {
  return msgStmts.listAll.all(sessionId);
}

function recentMessages(sessionId, n = 12) {
  return msgStmts.recent.all(sessionId, n).reverse();
}

function clearMessages(sessionId) {
  msgStmts.clear.run(sessionId);
}

// ---- 记忆摘要 ----
const memStmts = {
  upsert: db.prepare(`INSERT INTO memory_summaries (kind, ref_key, content) VALUES (?, ?, ?)
                      ON CONFLICT(kind, ref_key) DO UPDATE SET content = excluded.content, updated_at = datetime('now','localtime')`),
  byKind: db.prepare(`SELECT * FROM memory_summaries WHERE kind = ? ORDER BY id DESC`),
  byKey: db.prepare(`SELECT * FROM memory_summaries WHERE kind = ? AND ref_key = ?`),
};

function upsertSummary(kind, refKey, content) {
  memStmts.upsert.run(kind, String(refKey), content);
}
function listSummaries(kind) { return memStmts.byKind.all(kind); }
function getSummary(kind, refKey) { return memStmts.byKey.get(kind, String(refKey)); }

module.exports = {
  getProfile, updateProfile,
  addDiary, updateDiary, deleteDiary, listDiary, recentDiary,
  addMilestone, listMilestones, deleteMilestonesByDiary,
  addHealthRecord, listHealthRecords, deleteHealthRecord,
  addSession, renameSession, deleteSession, listSessions,
  upsertSummary, listSummaries, getSummary,
  addLetter, updateLetter, deleteLetter, sealLetter, voidLetter, openLetter, listLetters, getLetter,
  addMessage, listMessages, recentMessages, clearMessages,
};
