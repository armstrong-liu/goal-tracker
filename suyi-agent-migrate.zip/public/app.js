/* ============================================================
   Suyi 成长智能体 · 前端逻辑
   ============================================================ */

// ============ UI 基础组件：对话框 / Toast ============
function uiDialog({ title = '', body = '', input = null, okText = '确定', cancelText = '取消' }) {
  return new Promise(resolve => {
    const root = document.getElementById('dialog-root');
    const mask = document.createElement('div');
    mask.className = 'mask';
    mask.innerHTML = `
      <div class="dlg">
        ${title ? `<div class="dlg-title">${title}</div>` : ''}
        <div class="dlg-body">${body}</div>
        ${input !== null ? `<input class="dlg-input" value="${String(input).replace(/"/g, '&quot;')}">` : ''}
        <div class="dlg-btns">
          ${input !== null ? `<button class="cancel">${cancelText}</button>` : `<button class="cancel" data-x="1">${cancelText}</button>`}
          <button class="ok">${okText}</button>
        </div>
      </div>`;
    root.appendChild(mask);
    const inputEl = mask.querySelector('.dlg-input');
    const done = val => { root.innerHTML = ''; resolve(val); };
    mask.querySelector('.ok').addEventListener('click', () => done(inputEl ? inputEl.value : true));
    mask.querySelector('.cancel').addEventListener('click', () => done(inputEl ? null : false));
    mask.addEventListener('click', e => { if (e.target === mask) done(inputEl ? null : false); });
    document.addEventListener('keydown', function esc(e) {
      if (e.key === 'Escape') { document.removeEventListener('keydown', esc); done(inputEl ? null : false); }
      if (e.key === 'Enter' && inputEl) { document.removeEventListener('keydown', esc); done(inputEl.value); }
    });
    if (inputEl) { inputEl.focus(); inputEl.select(); }
  });
}
const uiAlert = body => uiDialog({ title: '提示', body, okText: '知道了', cancelText: '关闭' });
const uiConfirm = body => uiDialog({ title: '确认', body, okText: '确定', cancelText: '取消' });
const uiPrompt = (body, def = '') => uiDialog({ title: '输入', body, input: def, okText: '确定', cancelText: '取消' });

function toast(msg, err = false) {
  const root = document.getElementById('toast-root');
  const t = document.createElement('div');
  t.className = 'toast' + (err ? ' err' : '');
  t.textContent = msg;
  root.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

// ============ 导航（侧边栏 + 底部导航） ============
function switchTab(tab) {
  document.querySelectorAll('.side-item, .bottom-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tab);
  });
  document.querySelectorAll('.page').forEach(el => el.classList.remove('active'));
  document.getElementById(tab).classList.add('active');
  document.getElementById('more-menu').style.display = 'none';
  if (tab === 'chat') renderPresence();
  if (tab === 'diary') loadDiary();
  if (tab === 'timeline') loadTimeline();
  if (tab === 'health') loadHealth();
  if (tab === 'post') loadPost();
  if (tab === 'profile') loadProfile();
  if (tab === 'today') renderToday();
}
document.querySelectorAll('.side-item, .bottom-item[data-tab], .more-menu button[data-tab]').forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});
document.getElementById('more-btn').addEventListener('click', e => {
  e.stopPropagation();
  const m = document.getElementById('more-menu');
  m.style.display = m.style.display === 'none' ? 'block' : 'none';
});
document.addEventListener('click', () => { document.getElementById('more-menu').style.display = 'none'; });

// ============ 今日页 ============
function daysBetween(a, b) { return Math.floor((new Date(b) - new Date(a)) / 86400000); }
const todayStr = () => new Date().toISOString().slice(0, 10);

async function renderToday() {
  const [profile, diaries, milestones, healths, letters] = await Promise.all([
    fetch('/api/profile').then(r => r.json()),
    fetch('/api/diary').then(r => r.json()),
    fetch('/api/milestones').then(r => r.json()),
    fetch('/api/health').then(r => r.json()),
    fetch('/api/letters').then(r => r.json()),
  ]);
  const b = new Date(profile.birthday);
  const now = new Date();
  let months = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
  let days = now.getDate() - b.getDate();
  if (days < 0) { months -= 1; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
  const ageText = months >= 12
    ? `${Math.floor(months / 12)}岁${months % 12 ? months % 12 + '个月' : ''}${days ? '零' + days + '天' : ''}`
    : `${months}个月${days ? '零' + days + '天' : ''}`;
  const week = ['日', '一', '二', '三', '四', '五', '六'][now.getDay()];
  const lastDiaryDays = diaries.length ? daysBetween(diaries[0].date, todayStr()) : null;

  // 主卡
  const main = document.getElementById('t-main');
  main.innerHTML = `
    <div class="b-label">${todayStr().replace(/-/g, '.')} · 周${week}</div>
    <div class="b-value">${profile.name} · ${ageText}</div>
    <div class="b-sub">${lastDiaryDays === null ? '还没有日记，从今天开始记录吧'
      : lastDiaryDays === 0 ? '今天已经写过日记了 ✓'
      : `<span class="${lastDiaryDays >= 3 ? 'warn' : ''}">距上次日记 ${lastDiaryDays} 天</span>`}</div>`;

  // 日记卡
  const dCard = document.getElementById('t-diary');
  dCard.innerHTML = diaries.length
    ? `<div class="b-label">最新日记</div><div class="b-sub">${diaries[0].date}<br>${diaries[0].content.slice(0, 60)}…</div>
       <button class="b-link">续写今日日记 →</button>`
    : `<div class="b-label">日记</div><div class="b-sub">此刻的细节，就是未来的她想读的。</div><button class="b-link">写下第一篇 →</button>`;
  dCard.querySelector('.b-link').addEventListener('click', () => {
    switchTab('diary');
    setTimeout(() => document.getElementById('diary-content').focus(), 50);
  });

  // 里程碑卡
  const mCard = document.getElementById('t-milestone');
  const monthMs = milestones.filter(m => m.date.startsWith(todayStr().slice(0, 7)));
  mCard.innerHTML = milestones.length
    ? `<div class="b-label">新技能 · 本月 +${monthMs.length}</div>
       <div class="b-value" style="font-size:19px">★ ${milestones[0].event}</div>
       <div class="b-sub">${milestones[0].date}</div>
       <button class="b-link">全部里程碑 →</button>`
    : `<div class="b-label">里程碑</div><div class="b-sub">写日记时 AI 会自动记下她的每个"第一次"。</div>`;
  const mBtn = mCard.querySelector('.b-link');
  if (mBtn) mBtn.addEventListener('click', () => switchTab('timeline'));

  // 照片卡
  const pCard = document.getElementById('t-photos');
  const photos = diaries.filter(d => d.photo).slice(0, 6);
  pCard.innerHTML = photos.length
    ? `<div class="b-label">最近的她</div><div class="photo-strip">${photos.map(d => `<img src="${d.photo}" title="${d.date}">`).join('')}</div>`
    : `<div class="b-label">照片</div><div class="b-sub">写日记时附一张照片，让记忆有画面。</div>`;

  // 邮局卡
  const postCard = document.getElementById('t-post');
  const sealed = letters.filter(l => l.status === 'sealed');
  const arrivedN = sealed.filter(l => l.days_left <= 0).length;
  const nearest = sealed.filter(l => l.days_left > 0).pop();
  postCard.innerHTML = `
    <div class="b-label">时间邮局</div>
    ${arrivedN ? `<div class="b-value" style="font-size:19px;color:var(--accent)">📮 有 ${arrivedN} 封信到了</div>` : ''}
    ${nearest ? `<div class="b-sub">最近一封将在 ${nearest.unlock_at} 开启（还有 ${nearest.days_left} 天）</div>` : ''}
    ${!arrivedN && !nearest ? '<div class="b-sub">封存一封信，给未来的她。</div>' : ''}
    <button class="b-link">去时间邮局 →</button>`;
  postCard.querySelector('.b-link').addEventListener('click', () => switchTab('post'));

  // 体检卡
  const hCard = document.getElementById('t-health');
  const lastH = healths[healths.length - 1];
  hCard.innerHTML = lastH
    ? `<div class="b-label">上次体检 · ${daysBetween(lastH.date, todayStr())} 天前</div>
       <div class="b-value" style="font-size:20px">${lastH.height ?? '-'}cm · ${lastH.weight ?? '-'}kg</div>
       <div class="b-sub">${lastH.date}${lastH.teeth != null ? ` · 出牙 ${lastH.teeth} 颗` : ''}</div>`
    : `<div class="b-label">体检</div><div class="b-sub">还没有体检记录，儿保后录一次。</div>`;
}

// ============ 侧栏 Hero ============
async function renderHero() {
  const [profile, milestones, letters] = await Promise.all([
    fetch('/api/profile').then(r => r.json()),
    fetch('/api/milestones').then(r => r.json()),
    fetch('/api/letters').then(r => r.json()),
  ]);
  const b = new Date(profile.birthday);
  const now = new Date();
  let months = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
  let days = now.getDate() - b.getDate();
  if (days < 0) { months -= 1; days += new Date(now.getFullYear(), now.getMonth(), 0).getDate(); }
  const ageText = months >= 12
    ? `${Math.floor(months / 12)}岁${months % 12 ? months % 12 + '个月' : ''}` : `${months}个月`;
  document.getElementById('hero-age').textContent = `${profile.name} · ${ageText}`;
  const latest = milestones[0];
  document.getElementById('hero-latest').innerHTML = latest ? `★ ${latest.event}` : '';
  // 邮局红点
  const arrived = letters.filter(l => l.status === 'sealed' && l.days_left <= 0).length;
  ['post-dot', 'post-dot-m'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = arrived ? 'block' : 'none';
  });
}

// ============ 对话 ============
let mode = 'suyi';
document.querySelectorAll('.shell-chip').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.shell-chip').forEach(el => el.classList.remove('active'));
    btn.classList.add('active');
    mode = btn.dataset.mode;
  });
});

const chatBox = document.getElementById('chat-box');
const chatInput = document.getElementById('chat-input');
const chatSend = document.getElementById('chat-send');

// ---- 存在区：她的名片 ----
async function renderPresence() {
  try {
    const [profile, milestones] = await Promise.all([
      fetch('/api/profile').then(r => r.json()),
      fetch('/api/milestones').then(r => r.json()),
    ]);
    const b = new Date(profile.birthday);
    const now = new Date();
    let months = (now.getFullYear() - b.getFullYear()) * 12 + (now.getMonth() - b.getMonth());
    if (now.getDate() < b.getDate()) months -= 1;
    const ageText = months >= 12
      ? `${Math.floor(months / 12)}岁${months % 12 ? months % 12 + '个月' : ''}` : `${months}个月`;
    document.querySelector('#presence .p-name').childNodes[0].textContent = `${profile.name} `;
    document.getElementById('p-age').textContent = ageText;
    const latest = milestones[0];
    document.getElementById('p-status').innerHTML = latest
      ? `★ 最近的新本领：<b>${latest.event}</b>` : '在等你来聊天';
  } catch (e) { /* 静默 */ }
}

// ---- 消息渲染 ----
let lastMsgDate = null;

function addDateSepIfNeeded(createdAttr) {
  const d = (createdAttr || new Date().toISOString().slice(0, 10));
  if (d !== lastMsgDate) {
    const sep = document.createElement('div');
    sep.className = 'date-sep';
    sep.textContent = d;
    chatBox.appendChild(sep);
    lastMsgDate = d;
  }
}

function appendMsg(role, text, dateAttr) {
  addDateSepIfNeeded(dateAttr);
  const row = document.createElement('div');
  row.className = `msg-row ${role}`;
  if (role === 'assistant') {
    const av = document.createElement('div');
    av.className = 'msg-avatar'; av.textContent = 'S';
    const col = document.createElement('div');
    col.className = 'msg-col';
    const name = document.createElement('div');
    name.className = 'msg-name'; name.textContent = 'Suyi';
    const msg = document.createElement('div');
    msg.className = 'msg';
    msg.textContent = text;
    col.append(name, msg);
    row.append(av, col);
    chatBox.appendChild(row);
    chatBox.scrollTop = chatBox.scrollHeight;
    return msg;
  }
  const msg = document.createElement('div');
  msg.className = 'msg';
  msg.textContent = text;
  row.appendChild(msg);
  chatBox.appendChild(row);
  chatBox.scrollTop = chatBox.scrollHeight;
  return msg;
}

// 历史消息加载（带日期分隔）
async function loadMessages(sessionId) {
  if (!sessionId) return;
  const msgs = await (await fetch(`/api/messages?session_id=${sessionId}`)).json();
  chatBox.innerHTML = '';
  lastMsgDate = null;
  msgs.forEach(m => appendMsg(m.role, m.content, (m.created_at || '').slice(0, 10)));
  updateSuggestChips(msgs.length === 0);
}

// ---- 打字指示 ----
function showTyping() {
  const row = document.createElement('div');
  row.className = 'msg-row assistant';
  row.id = 'typing-row';
  row.innerHTML = `
    <div class="msg-avatar">S</div>
    <div class="msg-col">
      <div class="msg-name">Suyi</div>
      <div class="msg typing"><span class="d"></span><span class="d"></span><span class="d"></span><span class="t-label">她正朝你走来…</span></div>
    </div>`;
  chatBox.appendChild(row);
  chatBox.scrollTop = chatBox.scrollHeight;
}
function removeTyping() {
  const t = document.getElementById('typing-row');
  if (t) t.remove();
}

// ---- 快捷话头 ----
function updateSuggestChips(empty) {
  document.getElementById('suggest-chips').style.display = empty ? 'flex' : 'none';
}
document.querySelectorAll('#suggest-chips button').forEach(btn => {
  btn.addEventListener('click', () => {
    chatInput.value = btn.dataset.q;
    updateSendState();
    sendChat();
  });
});

// ---- 输入容器：自动增高 / Enter发送 / 按钮状态 ----
function updateSendState() {
  chatSend.disabled = !chatInput.value.trim();
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
}
chatInput.addEventListener('input', updateSendState);
chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!chatSend.disabled) sendChat(); }
});
chatInput.addEventListener('paste', () => setTimeout(updateSendState, 0));

// ---- 会话 ----
let currentSessionId = null;

async function loadSessions(selectId = null) {
  const sessions = await (await fetch('/api/sessions')).json();
  const sel = document.getElementById('session-select');
  sel.innerHTML = '';
  if (!sessions.length) {
    const opt = document.createElement('option');
    opt.value = ''; opt.textContent = '（还没有对话）';
    sel.appendChild(opt);
    currentSessionId = null;
    return;
  }
  sessions.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.textContent = `${s.title} · ${(s.last_at || s.created_at || '').slice(5, 10)}`;
    sel.appendChild(opt);
  });
  const target = selectId || (currentSessionId && sessions.some(s => s.id === currentSessionId) ? currentSessionId : sessions[0].id);
  sel.value = target;
  currentSessionId = Number(target);
  loadMessages(currentSessionId);
}

async function newSession() {
  chatBox.innerHTML = '';
  lastMsgDate = null;
  currentSessionId = null;
  updateSuggestChips(false);
  const sel = document.getElementById('session-select');
  const opt = document.createElement('option');
  opt.value = ''; opt.textContent = '她正在跑过来…';
  sel.innerHTML = ''; sel.appendChild(opt);
  // 她先开口：开场白以"她先开口了"卡片呈现（失败则静默）
  try {
    const res = await fetch('/api/chat/greet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode }),
    });
    const d = await res.json();
    if (d.greeting) {
      currentSessionId = d.session_id;
      const card = document.createElement('div');
      card.className = 'greet-card';
      card.innerHTML = `
        <div class="g-avatar">S</div>
        <div class="g-label">她先开口了</div>
        <div class="g-text"></div>`;
      card.querySelector('.g-text').textContent = d.greeting;
      chatBox.appendChild(card);
      chatBox.scrollTop = chatBox.scrollHeight;
      loadSessions(d.session_id);
      updateSuggestChips(false);
    }
  } catch (e) { updateSuggestChips(true); /* 静默，家长可先说话 */ }
}

document.getElementById('session-new').addEventListener('click', newSession);
document.getElementById('session-del').addEventListener('click', async () => {
  if (!currentSessionId) { chatBox.innerHTML = ''; return; }
  if (!await uiConfirm('删除这个对话？其所有消息将一并删除。')) return;
  await fetch(`/api/sessions/${currentSessionId}`, { method: 'DELETE' });
  chatBox.innerHTML = '';
  loadSessions();
});
document.getElementById('session-select').addEventListener('change', e => {
  currentSessionId = Number(e.target.value) || null;
  chatBox.innerHTML = '';
  if (currentSessionId) loadMessages(currentSessionId);
});

async function sendChat() {
  const text = chatInput.value.trim();
  if (!text) return;
  chatInput.value = '';
  updateSendState();
  appendMsg('user', text);
  updateSuggestChips(false);
  showTyping();
  const replyEl = { textContent: '' }; // placeholder，真正的元素在首个数据块时创建
  let msgNode = null;
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, mode, session_id: currentSessionId }),
    });
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let full = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      let chunk = decoder.decode(value, { stream: true });
      const errMatch = chunk.match(/\n\n@@ERROR@@([\s\S]*)$/);
      if (errMatch) {
        chunk = chunk.replace(/\n\n@@ERROR@@[\s\S]*$/, '');
        full += chunk;
        if (msgNode) msgNode.textContent = full + '\n[出错: ' + errMatch[1] + ']';
        break;
      }
      const doneMatch = chunk.match(/\n\n@@DONE@@(\d+)$/);
      if (doneMatch) {
        chunk = chunk.replace(/\n\n@@DONE@@\d+$/, '');
        full += chunk;
        const newSession = Number(doneMatch[1]);
        if (newSession && newSession !== currentSessionId) loadSessions(newSession);
        break;
      }
      if (chunk) {
        full += chunk;
        if (!msgNode) { removeTyping(); msgNode = appendMsg('assistant', ''); msgNode.classList.add('streaming'); }
        msgNode.textContent = full;
        chatBox.scrollTop = chatBox.scrollHeight;
      }
    }
    removeTyping();
    if (msgNode) msgNode.classList.remove('streaming');
    if (!full) { const m = appendMsg('assistant', '（没有收到回复）'); void m; }
  } catch (e) {
    removeTyping();
    appendMsg('assistant', '请求失败：' + e.message);
  }
  chatBox.scrollTop = chatBox.scrollHeight;
}

document.getElementById('chat-send').addEventListener('click', sendChat);
chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });

// ============ 日记 ============
const diaryForm = document.getElementById('diary-form');
document.getElementById('diary-date').value = todayStr();

async function loadDiary() {
  const list = document.getElementById('diary-list');
  const entries = await (await fetch('/api/diary')).json();
  if (!entries.length) {
    list.innerHTML = `<div class="empty">此刻的细节，就是未来的她想读的<br><button class="empty-action" onclick="switchTab('today')">返回今日</button></div>`;
    return;
  }
  list.innerHTML = '';
  entries.forEach(e => {
    const div = document.createElement('div');
    div.className = 'entry';
    const tags = (e.tags || '').split(/\s+/).filter(Boolean).map(t => `<span class="entry-tag">#${t}</span>`).join(' ');
    div.innerHTML = `
      <div class="entry-head"><span class="entry-date">${e.date}</span>${tags}</div>
      ${e.photo ? `<img class="entry-photo" src="${e.photo}">` : ''}
      <div class="entry-content"></div>
      <div class="entry-actions"><button class="edit">编辑</button><button class="del">删除</button></div>`;
    div.querySelector('.entry-content').textContent = e.content;
    div.querySelector('.del').addEventListener('click', async () => {
      if (!await uiConfirm('删除这条日记？')) return;
      await fetch(`/api/diary/${e.id}`, { method: 'DELETE' });
      loadDiary(); renderHero(); renderToday();
    });
    div.querySelector('.edit').addEventListener('click', () => {
      document.getElementById('diary-date').value = e.date;
      document.getElementById('diary-content').value = e.content;
      document.getElementById('diary-tags').value = e.tags || '';
      pendingPhoto = { url: e.photo || '', desc: e.photo_desc || '' };
      if (e.photo) {
        document.getElementById('photo-preview').style.display = 'block';
        document.getElementById('photo-img').src = e.photo;
        document.getElementById('photo-desc').textContent = e.photo_desc || '';
      }
      diaryForm.dataset.editId = e.id;
      diaryForm.scrollIntoView({ behavior: 'smooth' });
    });
    list.appendChild(div);
  });
}

// ---- 照片：拖拽上传 ----
let pendingPhoto = { url: '', desc: '' };
const dropzone = document.getElementById('photo-drop');
const fileInput = document.getElementById('diary-photo');
dropzone.addEventListener('click', () => fileInput.click());
dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('dragover'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
dropzone.addEventListener('drop', e => {
  e.preventDefault();
  dropzone.classList.remove('dragover');
  if (e.dataTransfer.files[0]) handlePhoto(e.dataTransfer.files[0]);
});
fileInput.addEventListener('change', () => { if (fileInput.files[0]) handlePhoto(fileInput.files[0]); });

async function handlePhoto(file) {
  if (!file.type.startsWith('image/')) { toast('只能上传图片', true); return; }
  const preview = document.getElementById('photo-preview');
  const descEl = document.getElementById('photo-desc');
  preview.style.display = 'block';
  descEl.textContent = '🔍 正在识别照片内容…';
  const reader = new FileReader();
  reader.onload = async () => {
    document.getElementById('photo-img').src = reader.result;
    try {
      const res = await fetch('/api/photo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: reader.result }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      pendingPhoto = data;
      descEl.textContent = data.desc ? '📝 ' + data.desc : '（未生成描述，已保存照片）';
      if (data.desc) document.getElementById('diary-content').value +=
        (document.getElementById('diary-content').value ? '\n' : '') + `[照片] ${data.desc}`;
      toast('照片已上传');
    } catch (err) {
      descEl.textContent = '上传失败：' + err.message;
    }
  };
  reader.readAsDataURL(file);
}

diaryForm.addEventListener('submit', async e => {
  e.preventDefault();
  const payload = {
    date: document.getElementById('diary-date').value,
    content: document.getElementById('diary-content').value,
    tags: document.getElementById('diary-tags').value,
    photo: pendingPhoto.url, photo_desc: pendingPhoto.desc,
  };
  const editId = diaryForm.dataset.editId;
  await fetch(editId ? `/api/diary/${editId}` : '/api/diary', {
    method: editId ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  delete diaryForm.dataset.editId;
  pendingPhoto = { url: '', desc: '' };
  document.getElementById('photo-preview').style.display = 'none';
  fileInput.value = '';
  diaryForm.reset();
  document.getElementById('diary-date').value = todayStr();
  loadDiary();
  renderHero();
  toast('日记已保存 ✓');
});

// ============ 时间轴 & 里程碑 ============
async function loadTimeline() {
  const [entries, milestones] = await Promise.all([
    fetch('/api/diary').then(r => r.json()),
    fetch('/api/milestones').then(r => r.json()),
  ]);
  const msList = document.getElementById('milestone-list');
  if (!milestones.length) {
    msList.innerHTML = `<div class="empty">每个"第一次"都值得被记下<br><button class="empty-action" onclick="switchTab('diary')">去写日记</button></div>`;
  } else {
    msList.innerHTML = '';
    milestones.forEach(m => {
      const chip = document.createElement('div');
      chip.className = 'entry';
      chip.innerHTML = `<div class="entry-head"><span class="star-sticker-lg">★</span><span class="entry-date">${m.date}</span><span class="entry-tag">${m.category}</span></div><div class="ms-event"></div>`;
      chip.querySelector('.ms-event').textContent = m.event;
      msList.appendChild(chip);
    });
  }
  const list = document.getElementById('timeline-list');
  if (!entries.length) {
    list.innerHTML = `<div class="empty">时间轴还是空的</div>`;
    return;
  }
  list.innerHTML = '';
  entries.forEach(e => {
    const isMilestone = /里程碑|第一次/.test(e.tags || '');
    const item = document.createElement('div');
    item.className = 'tl-item';
    item.innerHTML = `
      <div class="tl-date">${e.date} ${isMilestone ? '★' : ''}</div>
      <div class="tl-content"></div>`;
    item.querySelector('.tl-content').textContent = e.content;
    list.appendChild(item);
  });
}

// ============ 体检 & 报告 ============
document.getElementById('h-date').value = todayStr();
document.getElementById('report-month').value = todayStr().slice(0, 7);

document.getElementById('health-form').addEventListener('submit', async e => {
  e.preventDefault();
  await fetch('/api/health', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      date: document.getElementById('h-date').value,
      height: document.getElementById('h-height').value || null,
      weight: document.getElementById('h-weight').value || null,
      head_circ: document.getElementById('h-head').value || null,
      teeth: document.getElementById('h-teeth').value || null,
      note: document.getElementById('h-note').value,
    }),
  });
  e.target.reset();
  document.getElementById('h-date').value = todayStr();
  loadHealth();
  toast('体检记录已保存 ✓');
});

async function loadHealth() {
  const records = await (await fetch('/api/health')).json();
  const list = document.getElementById('health-list');
  if (!records.length) {
    list.innerHTML = `<div class="empty">每次儿保后录一次，成长曲线由此展开<br><button class="empty-action" onclick="document.getElementById('h-date').focus()">开始录入</button></div>`;
    return;
  }
  list.innerHTML = '';
  records.forEach(r => {
    const div = document.createElement('div');
    div.className = 'entry';
    div.innerHTML = `
      <div class="entry-head"><span class="entry-date">${r.date}</span></div>
      <div class="entry-content"></div>
      <div class="entry-actions"><button class="del">删除</button></div>`;
    div.querySelector('.entry-content').textContent =
      `身高 ${r.height ?? '-'} cm ｜ 体重 ${r.weight ?? '-'} kg ｜ 头围 ${r.head_circ ?? '-'} cm ｜ 出牙 ${r.teeth ?? '-'} 颗 ${r.note ? '｜ ' + r.note : ''}`;
    div.querySelector('.del').addEventListener('click', async () => {
      if (!await uiConfirm('删除这条体检记录？')) return;
      await fetch(`/api/health/${r.id}`, { method: 'DELETE' });
      loadHealth();
    });
    list.appendChild(div);
  });
}

function renderMd(md) {
  return md
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/^## (.+)$/gm, '<h3 style="font-family:var(--serif);font-weight:400;color:var(--accent);margin:16px 0 6px">$1</h3>')
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/\n/g, '<br>');
}

document.getElementById('report-gen').addEventListener('click', async () => {
  const month = document.getElementById('report-month').value;
  const box = document.getElementById('report-box');
  if (!month) return;
  box.innerHTML = '<div class="empty">✨ 正在生成报告，约需十几秒…</div>';
  try {
    const res = await fetch('/api/report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ month }),
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error);
    box.innerHTML = `<div class="report">${renderMd(data.report)}</div>`;
    document.getElementById('report-print').style.display = 'inline-block';
    toast('报告已生成 ✓');
  } catch (err) {
    box.innerHTML = `<div class="empty">生成失败：${err.message}</div>`;
  }
});

document.getElementById('report-print').addEventListener('click', () => window.print());

// ============ 时间邮局 ============
const letterForm = document.getElementById('letter-form');

async function loadPost() {
  await Promise.all([loadLetters(), loadDiaryOptions()]);
}

async function loadDiaryOptions() {
  const diaries = await (await fetch('/api/diary')).json();
  const sel = document.getElementById('l-diary');
  sel.innerHTML = '<option value="">（不关联）</option>';
  diaries.forEach(d => {
    const opt = document.createElement('option');
    opt.value = d.id;
    opt.textContent = `${d.date} ${d.content.slice(0, 15)}…`;
    sel.appendChild(opt);
  });
}

function daysLeftLabel(days) {
  if (days <= 0) return '已到解锁日';
  if (days < 365) return `还有 ${days} 天`;
  return `还有 ${Math.floor(days / 365)} 年 ${Math.round(days % 365 / 30)} 个月`;
}

async function loadLetters() {
  const letters = await (await fetch('/api/letters')).json();
  const list = document.getElementById('letter-list');
  const arrived = [], sealed = [], drafts = [], opened = [], voided = [];
  letters.forEach(l => {
    if (l.status === 'sealed' && l.days_left <= 0) arrived.push(l);
    else if (l.status === 'sealed') sealed.push(l);
    else if (l.status === 'draft') drafts.push(l);
    else if (l.status === 'opened') opened.push(l);
    else voided.push(l);
  });

  const box = document.getElementById('arrived-box');
  const alist = document.getElementById('arrived-list');
  if (arrived.length) {
    box.style.display = 'block';
    alist.innerHTML = '';
    arrived.forEach(l => {
      const div = document.createElement('div');
      div.className = 'letter-line';
      div.innerHTML = `<span>🔒→✉️ ${l.title || '无题'} · 寄于 ${(l.sealed_at || '').slice(0, 10)}</span>`;
      const btn = document.createElement('button');
      btn.textContent = '拆信';
      btn.addEventListener('click', async () => {
        if (!await uiConfirm(`拆开这封信？它等了从 ${(l.sealed_at || '').slice(0, 10)} 到今天。`)) return;
        await fetch(`/api/letters/${l.id}/open`, { method: 'POST' });
        loadLetters(); renderHero();
      });
      div.appendChild(btn);
      alist.appendChild(div);
    });
  } else {
    box.style.display = 'none';
  }

  list.innerHTML = '';
  const groups = [['待审核草稿', drafts], ['封存中（不可修改）', sealed], ['已拆的信', opened]];
  let any = false;
  for (const [label, items] of groups) {
    if (!items.length) continue;
    any = true;
    const h = document.createElement('div');
    h.className = 'group-label';
    h.textContent = label;
    list.appendChild(h);
    for (const l of items) list.appendChild(renderLetter(l));
  }
  if (!any) {
    list.innerHTML = `<div class="empty">此刻的你，就是未来的她想读的信<br><button class="empty-action" onclick="document.getElementById('l-title').focus()">写一封</button></div>`;
  }

  const vbox = document.getElementById('void-box');
  vbox.style.display = voided.length ? 'block' : 'none';
  const vlist = document.getElementById('void-list');
  vlist.innerHTML = '';
  voided.forEach(l => {
    const div = document.createElement('div');
    div.className = 'letter-line voided';
    div.textContent = `${l.title || '无题'} · ${l.author} · 已作废`;
    vlist.appendChild(div);
  });
}

document.getElementById('void-toggle').addEventListener('click', () => {
  const vlist = document.getElementById('void-list');
  const on = vlist.style.display !== 'none';
  vlist.style.display = on ? 'none' : 'block';
  document.getElementById('void-toggle').textContent = on ? '废信箱 ▸' : '废信箱 ▾';
});

function renderLetter(l) {
  const div = document.createElement('div');
  div.className = 'letter-entry' + (l.status === 'sealed' ? ' sealed' : '');
  if (l.status === 'sealed') div.dataset.stamp = `${l.unlock_at} · 开启`;
  const head = document.createElement('div');
  head.className = 'letter-head';
  head.innerHTML = `
    <span class="letter-title">${l.status === 'draft' ? '✏️' : l.status === 'sealed' ? '🔒' : '✉️'} ${l.title || '无题'}</span>
    <span class="letter-meta">${l.author} · 寄于 ${(l.sealed_at || l.created_at || '').slice(0, 10)}${l.status === 'sealed' ? ` · ${daysLeftLabel(l.days_left)}（${l.unlock_at} 开启）` : ''}</span>`;

  const actions = document.createElement('div');
  actions.className = 'entry-actions';
  if (l.status === 'draft') {
    const edit = document.createElement('button'); edit.textContent = '编辑';
    edit.addEventListener('click', () => fillLetterForm(l));
    const seal = document.createElement('button'); seal.textContent = '封存';
    seal.addEventListener('click', async () => {
      if (!await uiConfirm('封存后任何人（包括你）都不能再修改或提前查看，确定？')) return;
      await fetch(`/api/letters/${l.id}/seal`, { method: 'POST' });
      loadLetters(); renderHero(); toast('信已封存 🔒');
    });
    const del = document.createElement('button'); del.textContent = '删除';
    del.addEventListener('click', async () => {
      if (!await uiConfirm('删除这封草稿？')) return;
      await fetch(`/api/letters/${l.id}`, { method: 'DELETE' });
      loadLetters();
    });
    actions.append(edit, seal, del);
  } else if (l.status === 'sealed') {
    const voidBtn = document.createElement('button'); voidBtn.textContent = '作废';
    voidBtn.addEventListener('click', async () => {
      if (!await uiConfirm('作废这封信？它将进入废信箱，永远无法开启。')) return;
      await fetch(`/api/letters/${l.id}/void`, { method: 'POST' });
      loadLetters(); renderHero();
    });
    actions.append(voidBtn);
  }
  head.appendChild(actions);
  div.appendChild(head);

  if (l.content !== undefined) {
    const body = document.createElement('div');
    body.className = 'letter-body';
    body.textContent = l.content;
    div.appendChild(body);
    if (l.diary_id) {
      fetch('/api/diary').then(r => r.json()).then(all => {
        const d = all.find(x => x.id === l.diary_id);
        if (d) {
          const att = document.createElement('div');
          att.className = 'letter-attach';
          att.textContent = `📎 附：${d.date} 的日记 — ${d.content.slice(0, 40)}…`;
          div.appendChild(att);
        }
      });
    }
  }
  return div;
}

function fillLetterForm(l) {
  document.getElementById('l-edit-id').value = l.id;
  document.getElementById('l-title').value = l.title || '';
  document.getElementById('l-content').value = l.content || '';
  document.getElementById('l-unlock').value = l.unlock_at;
  document.getElementById('l-author').value = l.author;
  document.getElementById('l-diary').value = l.diary_id || '';
  letterForm.scrollIntoView({ behavior: 'smooth' });
}

letterForm.addEventListener('submit', async e => {
  e.preventDefault();
  const payload = {
    title: document.getElementById('l-title').value,
    content: document.getElementById('l-content').value,
    author: document.getElementById('l-author').value,
    recipient: 'Suyi',
    unlock_at: document.getElementById('l-unlock').value,
    diary_id: document.getElementById('l-diary').value ? Number(document.getElementById('l-diary').value) : null,
  };
  if (!payload.unlock_at) { uiAlert('请选择解锁日'); return; }
  const editId = document.getElementById('l-edit-id').value;
  await fetch(editId ? `/api/letters/${editId}` : '/api/letters', {
    method: editId ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  document.getElementById('l-edit-id').value = '';
  letterForm.reset();
  document.getElementById('l-author').value = '爸爸妈妈';
  loadLetters();
  toast('草稿已保存 ✓');
});

async function aiDraft(style) {
  const btns = ['l-ai-assist', 'l-ai-suyi', 'l-ai-snapshot'].map(id => document.getElementById(id));
  btns.forEach(b => b.disabled = true);
  const contentEl = document.getElementById('l-content');
  let note = '';
  if (style === 'assist') {
    note = await uiPrompt('你想对未来的她说什么？一两句话即可，AI帮你展开：');
    if (note === null) { btns.forEach(b => b.disabled = false); return; }
  }
  contentEl.value = '（AI 正在写信…）';
  try {
    const res = await fetch('/api/letters/ai-draft', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ style, userNote: note, month: todayStr().slice(0, 7) }),
    });
    const d = await res.json();
    if (d.error) throw new Error(d.error);
    document.getElementById('l-edit-id').value = d.id;
    document.getElementById('l-title').value = d.title;
    contentEl.value = d.content;
    document.getElementById('l-unlock').value = d.unlock_at;
    document.getElementById('l-author').value = d.author;
    toast('AI草稿已生成，请审阅修改');
    loadLetters();
  } catch (err) {
    contentEl.value = '';
    toast('生成失败：' + err.message, true);
  } finally {
    btns.forEach(b => b.disabled = false);
  }
}
document.getElementById('l-ai-assist').addEventListener('click', () => aiDraft('assist'));
document.getElementById('l-ai-suyi').addEventListener('click', () => aiDraft('suyi_voice'));
document.getElementById('l-ai-snapshot').addEventListener('click', () => aiDraft('snapshot'));

// ============ 档案 ============
const FIELDS = ['name', 'birthday', 'family', 'personality', 'favorites', 'current_stage'];
async function loadProfile() {
  const p = await (await fetch('/api/profile')).json();
  FIELDS.forEach(f => { const el = document.getElementById('p-' + f); if (el) el.value = p[f] || ''; });
}
document.getElementById('profile-form').addEventListener('submit', async e => {
  e.preventDefault();
  const patch = {};
  FIELDS.forEach(f => { const el = document.getElementById('p-' + f); if (el) patch[f] = el.value; });
  await fetch('/api/profile', {
    method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch),
  });
  renderHero();
  toast('档案已保存 ✓');
});

// ============ 启动 ============
renderHero();
renderToday();
loadSessions();
renderPresence();
